




    const nameInput = document.getElementById("name");
    const showElement = document.getElementById("show");
    const showButton = document.getElementById("Showbtn");

    
    showButton.addEventListener("click", function() {
        
        showElement.innerText = nameInput.value;
    });

// booking

    // var submitButton = document.getElementById("btn2");
    //     submitButton.addEventListener("click", function() {
    //         document.querySelector(".formDetail").style.display = "none";
    //         document.querySelector(".container").style.display = "block";
    //         document.querySelector("#user_name").innerText =  document.querySelector("#username").value
    //         document.querySelector("#Phone").innerText =  document.querySelector("#number").value
    //         document.querySelector("#emailid").innerText =  document.querySelector("#email").value
    //         document.getElementById("btn2").innerText="Pay Now"

    //     });
//  const dropdown = document.querySelector('.dropdown');
//  dropdown.addEventListener('click',()=>{
//     console.log("hello")
//     dropdown.classList.toggle('active');
//  });


