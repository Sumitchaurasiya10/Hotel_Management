// script.js
function validateForm() {
    // Implement form validation logic here (e.g., check if check-in date is before check-out date)
    const checkIn = document.getElementById('checkIn').value;
    const checkOut = document.getElementById('checkOut').value;

    if (new Date(checkIn) >= new Date(checkOut)) {
        alert('Check-out date must be later than check-in date.');
        return false;
    }

    return true;
}

// Listen for changes in the payment method selection
document.getElementById('payment').addEventListener('change', function() {
    const paymentDetails = document.getElementById('paymentDetails');
    paymentDetails.innerHTML = '';

    // Add appropriate payment fields based on the selected payment method
    const paymentMethod = this.value;

    if (paymentMethod === 'credit_card' || paymentMethod === 'debit_card') {
        paymentDetails.innerHTML = `
            <div class="form-group">
                <label for="cardNumber">Card Number:</label>
                <input type="text" id="cardNumber" name="cardNumber" required>
            </div>
            <div class="form-group">
                <label for="expiryDate">Expiry Date:</label>
                <input type="month" id="expiryDate" name="expiryDate" required>
            </div>
            <div class="form-group">
                <label for="cvv">CVV:</label>
                <input type="text" id="cvv" name="cvv" required>
            </div>
        `;
    } else if (paymentMethod === 'paypal') {
        paymentDetails.innerHTML = `
            <div class="form-group">
                <label for="paypalEmail">PayPal Email:</label>
                <input type="email" id="paypalEmail" name="paypalEmail" required>
            </div>
        `;
    }
});

var input =document.getElementById("checkIn")
var output =document.getElementById("checkOut")
var valuein=0;
var valueout=0;
var book = document.getElementById("sub").addEventListener("click",function(){
    document.querySelector(".bill-infon").innerText =  document.querySelector("#name").value
    document.querySelector(".bill-infoe").innerText =  document.querySelector("#email").value
    document.querySelector(".bill-infop").innerText =  document.querySelector("#phone").value
    document.querySelector(".bill-infop").innerText =  document.querySelector("#phone").value
    document.querySelector(".bill-infor").innerText =  document.querySelector("#roomType").value
    document.querySelector("#adult").innerText = counter.innerHTML;
    document.querySelector("#child").innerText = counter1.innerText;
   






   document.getElementById("datein").innerText= input.value;
    document.getElementById("dateout").innerText=output.value;
    // document.querySelector(".box").style.display = "none";
    // document.querySelector("#bill").style.display = "block";
    // document.getElementById("sub").style.top="-50px"
    // document.getElementById("sub").innerText="Pay Now"
    

    
})
// var submitButton = document.getElementById("btn2");
//         submitButton.addEventListener("click", function() {
//             document.querySelector(".formDetail").style.display = "none";
//             document.querySelector(".container").style.display = "block";
//             document.querySelector("#user_name").innerText =  document.querySelector("#username").value
//             document.querySelector("#Phone").innerText =  document.querySelector("#number").value
//             document.querySelector("#emailid").innerText =  document.querySelector("#email").value
//             document.getElementById("btn2").innerText="Pay Now"

//         });

   // Get elements
   const counterAdult = document.getElementById('counter');
   const counterChild = document.getElementById('counter1');
   const addAdult = document.getElementById('add');
   const subtractAdult = document.getElementById('less');
   const addChild = document.getElementById('add1');
   const subtractChild = document.getElementById('less1');

   // Initialize total amount
   let totalAmount = 0;

   // Function to update total amount
   function updateTotalAmount() {
       totalAmount = parseInt(counterAdult.textContent) * 2000 + parseInt(counterChild.textContent) * 1000;
        document.querySelector(".total").innerText = "Total Amount: Rs "+ totalAmount
   }

   // Function to handle increment
   function incrementCounter(element) {
       const counter = element === 'adult' ? counterAdult : counterChild;
       counter.textContent = parseInt(counter.textContent) + 1;
       updateTotalAmount();
   }

   // Function to handle decrement
   function decrementCounter(element) {
       const counter = element === 'adult' ? counterAdult : counterChild;
       if (parseInt(counter.textContent) > 0) {
           counter.textContent = parseInt(counter.textContent) - 1;
           updateTotalAmount();
       }
   }

   // Event listeners
   addAdult.addEventListener('click', () => incrementCounter('adult'));
   subtractAdult.addEventListener('click', () => decrementCounter('adult'));
   addChild.addEventListener('click', () => incrementCounter('child'));
   subtractChild.addEventListener('click', () => decrementCounter('child'));


